package com.selenium;
import java.io.File;
import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class LocateByLinkTextEg {
public static void main(String[] args) throws Exception{
	//chrome driver path
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");

	//Create an instance of driver
	WebDriver driver = new ChromeDriver();

	//Load web page under Test
	driver.get("C:\\\\Users\\\\Administrator\\\\eclipse-workspace\\\\com.selenium\\\\src\\\\main\\\\resources\\\\LocateByLinkTextEg.html");
	
	//create WebDriverWait
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	
	WebElement link1 = driver.findElement(By.linkText("Visit Example"));
	File screenshot1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	FileHandler.copy(screenshot1, new File("./screenshot1.png"));
	link1.click();
	
	Thread.sleep(3000);
	System.out.println("Next Page Title :"+ driver.getTitle());
	
	File screenshot2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	FileHandler.copy(screenshot2, new File("./screenshot2.png"));
	
	WebElement infoLink = driver.findElement(By.partialLinkText("information"));
	infoLink.click();
	Thread.sleep(3000);
	File screenshot3 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	FileHandler.copy(screenshot3, new File("./screenshot3.png"));
	System.out.println("Next Page Title :"+ driver.getTitle());
	Thread.sleep(5000);
	driver.quit();
}
}