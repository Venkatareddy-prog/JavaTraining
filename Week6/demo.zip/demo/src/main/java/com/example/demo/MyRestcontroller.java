package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyRestcontroller {
	
	@GetMapping("/hi")
	public String met() {
		return "HelloPriya";
	}
	@GetMapping("/url")
	public String met1() {
		return "This is the new url";
	}
	@GetMapping("/per")
	public Person met2() {
		return new Person(1,"some name");
	}

}
