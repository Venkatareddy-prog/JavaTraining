package com.example.demo_ticket.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo_ticket.model.Ticket;
import com.example.demo_ticket.repository.TicketRepository;

@Service
public class TicketService {
    
    @Autowired
    TicketRepository ticketRepo;  // Dependency Injection

    public Ticket getTicketServ(int ticketid) {
    	Optional<Ticket> oticket= ticketRepo.findById(ticketid);
        return oticket.get();
    }

    public Ticket bookTicketServ(Ticket ticket) {
        return ticketRepo.save(ticket);
    }

     public List<Ticket> getTicketFromToPlace(String fromplace,String toplace ){
    	 return ticketRepo.findByFromplaceOrToplace(fromplace, toplace);
     }
   public Ticket updateTicketServ(int tid, Ticket ticket) {
	   Ticket eticket = ticketRepo.findById(tid).get();
	   eticket.setFromplace(ticket.getFromplace());
	   eticket.setToplace(ticket.getToplace());
	   eticket.setPrice(ticket.getPrice());
        return ticketRepo.save(eticket);
    }

    public Ticket cancelTicketRepo(int ticketid) {
        Ticket ticket = ticketRepo.findById(ticketid).get();
        ticketRepo.deleteById(ticketid);
        return ticket;
    }
}