package com.example.User.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.User.model.User;
import com.example.User.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository uRepo;

    public User createUser(User user) {
        return uRepo.save(user);
    }

    public User getUser(long userid) {
        Optional<User> ouser = uRepo.findById(userid);
        return ouser.orElse(null);
    }
}
