package com.utils;

// Singleton: Can create one and only one object
public class ArrayUtils {
    private int[] array;
    private static ArrayUtils m_obj = null; // Reference to the single instance

    // Private constructor to prevent instantiation
    private ArrayUtils(int[] array) {
        this.array = array;
    }

    // Static method to get the single instance of the class
    public static ArrayUtils getInstance(int[] array) {
        
        if (m_obj == null) {
        	m_obj = new ArrayUtils(array);
        }
        return m_obj; 
    }

    // Method to find the minimum value in the array
    public int min() {
        int min_val = array[0];
        for (int i = 1; i < array.length; i++) {
            if (array[i] < min_val) {
                min_val = array[i];
            }
        }
        return min_val;
    }

    // Placeholder methods for other functionalities (max, avg, etc.)
    // public int max() { ... }
    // public double avg() { ... }
}
